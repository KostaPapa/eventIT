<?php
$mysqli = new mysqli("localhost", "root", "0455642", "eventit");

if (mysqli_connect_errno()) {
  echo "Connection Failed: " . mysqli_connect_errno();
  exit();
}
?>
