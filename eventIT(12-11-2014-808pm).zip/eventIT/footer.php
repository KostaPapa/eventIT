<div id="footer">
    Copyright © Team B10
    <style>
        #footer { 
        	bottom: 0;
        	position: fixed;
        	background-color:purple; 
        	color:white; 
        	text-align:center;
        	padding:5px; 
        	margin-top: 2em;
        }
    </style>
</div>